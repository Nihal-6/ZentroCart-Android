# ZentroCart Android starter (₹0)

This is a starter Android WebView app with a local fashion-store page and a sample order form.
It is not a finished e-commerce backend: the sample products/prices must be replaced, and orders are not stored remotely. Before using with customers, configure the shop's WhatsApp number in `app/src/main/assets/index.html` (search for `const phone=''` and replace the empty value with the country code + number, digits only, e.g. `919876543210`). The form then opens a WhatsApp order message. Without that number, the sample form downloads an order text file instead.

## Build a debug APK free using GitHub Actions on Android

1. Download and extract this ZIP on your phone using your file manager.
2. Sign in to GitHub and create a new repository named `ZentroCart-Android`.
   - For the simplest free build, make it **Public**. Do not put private keys, passwords, customer data, or secrets in this repository.
3. In the new repository, choose **Add file → Upload files**. Upload the *contents* of the extracted folder, including the `.github` folder. Do not upload only the ZIP file.
   - If the phone browser cannot upload a folder, use GitHub's web editor to create/upload the files while preserving their exact paths, or use a trusted computer.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab and select **Build ZentroCart APK**. If prompted, enable workflows, then click **Run workflow**.
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run, scroll to **Artifacts**, and download `ZentroCart-debug-apk`.
8. Extract the downloaded artifact ZIP. Tap `app-debug.apk` to install it. Android may ask you to allow installation from that browser/file manager; only allow it for the trusted source you used.
9. Test the app and order form before sharing it.

## Customize before real sales

- Edit the sample names and prices in `app/src/main/assets/index.html`.
- Replace the emoji placeholders with your own product images if desired.
- Configure the shop WhatsApp number as described above.
- Add actual delivery, returns, and contact details.
- The app currently does not have a cart, automatic total calculation, stock management, UPI gateway, or online order database. Confirm each order and payment manually.

## Cost and limits

The source project and build approach are designed to cost ₹0 using GitHub Actions within its free allowance. GitHub limits and policies can change. This produces a debug APK for testing/direct sharing, not a Google Play release. Google Play publishing has a separate developer registration fee.
